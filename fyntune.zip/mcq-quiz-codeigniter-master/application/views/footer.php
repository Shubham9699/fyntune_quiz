<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <p>Powered by <a href="http://imeshbd.com" style="color: #ffffff; text-decoration: underline;" target="_blank">i-Mesh Limited</a></p>
            </div>
        </div>
    </div>
</footer>


</body>
</html>