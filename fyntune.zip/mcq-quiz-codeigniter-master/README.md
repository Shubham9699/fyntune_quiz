## Quiz Application
A simple quiz application by using codeigniter.

## Screenshot
![1](https://github.com/masudncse/mcq-quiz-codeigniter/blob/master/screenshot/1.png)
![2](https://github.com/masudncse/mcq-quiz-codeigniter/blob/master/screenshot/2.png)
![3](https://github.com/masudncse/mcq-quiz-codeigniter/blob/master/screenshot/3.png)
![4](https://github.com/masudncse/mcq-quiz-codeigniter/blob/master/screenshot/4.png)
